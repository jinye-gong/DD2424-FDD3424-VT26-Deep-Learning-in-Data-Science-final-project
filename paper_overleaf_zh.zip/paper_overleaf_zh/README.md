# DD2424 小组 148 — 中文报告（Overleaf）

## 编译器

**pdfLaTeX**（Overleaf 默认即可，无需 XeLaTeX）

- 主文件：`main.tex`
- 中文方案：**CJKutf8 + gbsn**（不依赖 `ctex`，兼容 TeX Live 2025）

若项目里有名为 `output.pdf` 的文件，请删除或改名后再编译。

## 上传说明

请上传 **`paper_overleaf_zh.zip`** 全文，或至少替换 `main.tex` 为最新版。

## 页数

正文 ≤ 6 页（参考文献不计）。

## 英文版

使用 **`paper_overleaf_en.zip`**。
