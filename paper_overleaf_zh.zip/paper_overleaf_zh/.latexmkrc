# pdfLaTeX（Overleaf 默认）
$pdf_mode = 1;
