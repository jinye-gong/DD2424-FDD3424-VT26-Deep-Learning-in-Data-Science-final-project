# DD2424 Group 148 — English Report (Overleaf)

## Files

| File | Role |
|------|------|
| `main.tex` | Main document (English) |
| `neurips_2026.sty` | NeurIPS-style layout |
| `references.bib` | Bibliography |
| `figures/` | Experiment plots |

## Overleaf

1. **New Project → Upload Project** → upload this zip.
2. Main document: **`main.tex`** (default).
3. Compiler: **pdfLaTeX** + **BibTeX** (or latexmk).
4. Page limit (course): **6 pages** body, references excluded.

Optional: replace `neurips_2026.sty` with official [NeurIPS 2021 style](https://neurips.cc) if required.

## Related

Chinese version: `paper_overleaf_zh.zip` in the repo root.
